
public class Parser {
	String s;
	String [] tokens;
	int length=0;
	static int i=0;
	TreeNode root;
	static String delims="[ ]";
	
  Parser(String str)
  {
	  length=0;
	  root=null;
	  s=str;
	  tokens = s.split(" ");   //tokens[] now contains individual query terms (with operators)
	  length=tokens.length;
	  for(int i=0;i<length;i++)
	  System.out.println(tokens[i]);
  }
  
  void create_tree(TreeNode rooti)
  {
  	TreeNode temp=new TreeNode();
  	//System.out.println(tokens.toString());
  	if (i==length)
  		return;
  	if(tokens[i].startsWith("#"))
  		{
  		  temp=new TreeNode(tokens[i]);
  		  if (i!=0)      //Check whether it is the root node or not
  		  {
  		    temp.parent=rooti;
  		    //System.out.println(temp.q);
  		    //System.out.println(temp.isLeaf);
  		    rooti.addChild(temp);
  		    //System.out.println(temp.parent.q);
  		    
  		  }
  		  if(i==0)
  		  {
  			  root=new TreeNode(temp);
  		  }
  		  i=i+2;
  		  create_tree(temp);
  		} 
  	
  	else if(tokens[i].equals(")"))
  		{
  		  i++;
  		  create_tree(rooti.parent);
  		}
  	
  	else
  	{
  		temp=new TreeNode(tokens[i]);
  		temp.parent=new TreeNode(rooti);
  		//System.out.println(temp.parent.q);
  	    i++;
  	    rooti.addChild(temp);
  	    temp.isLeaf=true;
  	    //System.out.println(temp.q);
  	    //System.out.println(temp.isLeaf);
  	    create_tree(temp.parent);
  	}
  }
  
  Qryop [] dfs(TreeNode node)
  {
	 Qryop[] a = new Qryop[node.children.size()];
	 //System.out.println(node.children.size());
	 for(int i=0;(i<node.children.size());i++)
	  {
		 System.out.println(i);
	     if(node.q.equals("#AND"))
	     { 
	      //System.out.println(node.children.get(i).q)
		    	 a[i] = new QryopAnd(dfs(node.children.get(i)));
		    	 //System.out.println(a[i]);
	     }
	  
		 if(node.q.equals("#OR"))
	    {
			 //System.out.println(node.children.get(i).q);	
				  System.out.println(node.children.get(i).q);
				  a[i] = new QryopOr(dfs(node.children.get(i)));
				  //System.out.println(a[i]);
	    }
	  if(node.q.equals("#NEAR"))
	  {
		  
	  }
	 else if (node.children.get(i).isLeaf)   //Not entering here because number of children for leaf nodes is 0
	  {
		  System.out.println(node.q);
		  a[i] =  new QryopTerm(node.children.get(i).q);
	  }
    }
  return a;
 }
}

	 

